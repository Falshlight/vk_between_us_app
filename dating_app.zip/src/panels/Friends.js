import React, {useEffect, useState} from 'react';
import PropTypes from 'prop-types';
import {platform, IOS, ModalCard, FormLayout, ModalRoot} from '@vkontakte/vkui';
import Panel from '@vkontakte/vkui/dist/components/Panel/Panel';
import PanelHeader from '@vkontakte/vkui/dist/components/PanelHeader/PanelHeader';
import PanelHeaderButton from "@vkontakte/vkui/dist/components/PanelHeaderButton/PanelHeaderButton";
import Icon28ChevronBack from '@vkontakte/icons/dist/28/chevron_back';
import Icon24Back from '@vkontakte/icons/dist/24/back';
import Group from "@vkontakte/vkui/dist/components/Group/Group";
import RichCell from "@vkontakte/vkui/dist/components/RichCell/RichCell";
import Avatar from "@vkontakte/vkui/dist/components/Avatar/Avatar";
import Button from "@vkontakte/vkui/dist/components/Button/Button";
import Checkbox from "@vkontakte/vkui/dist/components/Checkbox/Checkbox";
import Div from '@vkontakte/vkui/dist/components/Div/Div';


import getFriends, {backend_url} from "./utils";
import axios from 'axios';
import './Friends.css';

var _ = require('lodash');


const osName = platform();

const Friends = props => {
    const [activeModal, setActiveModal] = useState(null);
    const [currentUserIndex, setCurrentUserIndex] = useState(0);
    const [vkFriends, setVkFriends] = useState([]);
    const [upd, setUpd] = useState(0);
    var opts = props.optionsList;

    useEffect( () => {
        if (props.at.length) {
            console.log('do: ' + props.at);
            getFriends(props.at).then((data) => {
                setVkFriends(data.response.items);

            });
        }

    }, [props.at]);

    useEffect(() => {
        if (props.fetchedUser) {
            console.log('upda');
            axios.post(backend_url+'get-friends?uid='+props.fetchedUser.id+'&hash='+props.hash, {'friends': vkFriends, 'uid': props.fetchedUser['id'], 'filter': props.filter},
            ).then((data) => {
                console.log(data.data);
                if (!_.isEqual(data.data, friends)) props.setFriends(data.data);
            }).catch(() => {
                setUpd(Math.random());
            });
        }
    }, [vkFriends, upd]);

    function timer() {
        setUpd(Math.random());
    }

   useEffect(() => {
       setInterval(timer, 10000);

       return function cleanup() {
           clearInterval(timer);
       };
   }, []);



    function openModal(e) {
        if (e) {
            var ind = e.target.children[0].dataset.ind;
            let friend = friends[ind];
            if (!friend) return;
            let o = friend.options;

            setCurrentUserIndex(ind);
            setTimeout(() => {
                for (var i = 0; i < o.length; i++) {
                    var oid = o[i]['index'];
                    document.getElementById("checkbox-"+(oid-1)).checked = true;
                }
            }, 100);
        }
        setActiveModal("friend-options");
    }

    function closeModal() {
        setActiveModal(null);
    }

    function applyModal() {
        var checked_opts = [];
        for (var i = 0; i < opts.length; i++) {
            var el = document.getElementById("checkbox-"+i);
            if (el.checked) {
                checked_opts.push(i+1);
            }
            el.checked = false;
        }

        axios.post(backend_url+'set-options?uid='+props.fetchedUser.id+'&hash='+props.hash, {'to': friends[currentUserIndex]['id'], 'from': props.fetchedUser.id, 'options': checked_opts}).then(() => {
            setUpd(Math.random());
        });
        closeModal();

    }

    var friends = props.friends;

    function getText(i) {
        try {
            if (!friends[i].options.length) {
                return 'Нет свойств';
            } else {
                let o = [];
                for (var j = 0; j < friends[i].options.length; j++) {
                    var op = friends[i].options[j];
                    o.push(opts[op['index']-1])

                }
                return o.join(', ');
            }
        } catch (e) {}

    }

    function getCaption(i) {
        try {
            if (!friends[i].options.length) {
                return '';
            } else {
                let o = [];
                for (var j = 0; j < friends[i].options.length; j++) {
                    var op = friends[i].options[j];
                    if (op.show) o.push(opts[op['index']-1]);

                }
                if (o.length) return 'Совпало: ' + o.join(', ');
                else return '';
            }
        } catch (e) {}
    }

    function drawCircle(draw) {
        var el = document.getElementById("header-circle");
        if (el) el.remove();
        if (draw) {
            el = document.createElement("div");
            el.id = 'header-circle';
            var parent = document.getElementsByClassName("PanelHeader__content")[1];
            if (!parent)  parent = document.getElementsByClassName("PanelHeader__content")[0];
            parent.appendChild(el);
        }

    }

    function drawFriends() {
        var result = [];
        var draw_circle = false;

        for (var i = 0; i < friends.length; i++) {
            var friend = friends[i];
            if (!friend.options) return ;
            var inc = friend.options.map((x) => {
                if (x.show && !x.checked) return 1;
                else return 0;
            }).includes(1);
            if (inc) draw_circle = true;
            result.push(<RichCell
                before={<Avatar data-id={i} size={48} src={friend.photo_100} className={inc ? 'new-match' : 'no-new-match'} />}
                multiline
                caption={getCaption(i)}
                actions={
                    <React.Fragment>
                        <Button mode="secondary" onClick={openModal} data-ind={i}>Изменить<span data-ind={i}></span></Button>
                    </React.Fragment>
                }

                text={getText(i)}
                onClick={(e) => {

                    var id = e.target.dataset.id;
                    if (id) {
                        axios.get(backend_url+'check?uid='+props.fetchedUser.id+'&check_id='+friends[id].id+'&uid='+props.fetchedUser.id+'&hash='+props.hash).then((data) => {
                            setUpd(Math.random());
                        });
                    }

                }}
            >
                {friend.first_name + " " + friend.last_name}
            </RichCell>);
        }
        drawCircle(draw_circle);
        return result;
    }

    return (
        <Panel id={props.id}>
            <PanelHeader
                left={<PanelHeaderButton onClick={props.go} data-to="home">
                    {osName === IOS ? <Icon28ChevronBack/> : <Icon24Back/>}
                </PanelHeaderButton>}
            >
                Друзья
            </PanelHeader>
            <Group title="Список друзей">
                <Div style={{overflowY: 'auto', maxHeight: 'calc(100vh - 93px)'}}>
                    {drawFriends()}
                </Div>
            </Group>

            <ModalRoot
                activeModal={activeModal}
                onClose={closeModal}
            >
                <ModalCard
                    id="friend-options"
                    className="tst"
                    header="Выберите свойства"
                    onClose={closeModal}
                    actions={[{title: 'Применить', mode: 'primary', action: applyModal}]}
                >
                    <FormLayout>
                        {(() => {
                            let a = [];
                            for (var i = 0; i < opts.length; i++) {
                                a.push(<Checkbox id={'checkbox-'+i}>{opts[i]}</Checkbox>);
                            }
                            return a;
                        })()}
                    </FormLayout>
                </ModalCard>
            </ModalRoot>
        </Panel>
    );
};

Friends.propTypes = {
    id: PropTypes.string.isRequired,
    go: PropTypes.func.isRequired,
};

export default Friends;
